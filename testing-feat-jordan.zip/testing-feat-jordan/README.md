# corner-stone
Dashboard, volunteer and donation manager web application
