"use client"

export function HomePage() {

  return (
    <div>This is a test page</div>
  )
}